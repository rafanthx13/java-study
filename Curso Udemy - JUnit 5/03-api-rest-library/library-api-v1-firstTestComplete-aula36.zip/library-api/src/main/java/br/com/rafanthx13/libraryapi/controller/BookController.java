package br.com.rafanthx13.libraryapi.controller;

import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import br.com.rafanthx13.libraryapi.data.dto.BookDTO;
import br.com.rafanthx13.libraryapi.data.entity.Book;
import br.com.rafanthx13.libraryapi.service.BookService;

@RestController // Controlador Rest
@RequestMapping("/api/books") // Base URL
public class BookController {

  private BookService service;
  private ModelMapper modelMapper;

  public BookController(BookService service, ModelMapper modelMapper){
    this.service = service;
    this.modelMapper = modelMapper;
  }

  @PostMapping
  @ResponseStatus(HttpStatus.CREATED)
  public BookDTO create(@RequestBody BookDTO dto){
    // converto dto em uma entity Book
    Book entity = modelMapper.map(dto, Book.class);
    entity = service.save(entity);
    // AO voltar, converto de uma entity apra dtp
    return modelMapper.map(entity, BookDTO.class);
    

    
  }
  
}