package br.com.rafanthx13.libraryapi.data.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

// lobok
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Book {

  private Long id;

  private String title;

  private String author;

  private String isbn;

}