package br.com.rafanthx13.libraryapi.service;

import br.com.rafanthx13.libraryapi.data.entity.Book;

public interface BookService {

  Book save(Book any);
}