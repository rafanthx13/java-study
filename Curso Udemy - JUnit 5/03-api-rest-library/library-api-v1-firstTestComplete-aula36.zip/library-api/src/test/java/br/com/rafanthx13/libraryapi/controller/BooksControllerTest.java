package br.com.rafanthx13.libraryapi.controller;

import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.BDDMockito;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import br.com.rafanthx13.libraryapi.data.dto.BookDTO;
import br.com.rafanthx13.libraryapi.data.entity.Book;
import br.com.rafanthx13.libraryapi.service.BookService;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

// @RunWith(SpringRunner.class) // JUnit 4
@ExtendWith(SpringExtension.class) // Para JUnit5
@ActiveProfiles("test") // que tipo de contexto de test estamos faendo
@WebMvcTest 
@AutoConfigureMockMvc // configurar para fazer as requisições
public class BooksControllerTest {

  static String BOOK_API = "/api/books";

  @Autowired // gera e injeta o objeto automaticamente
  MockMvc mvc;

  @MockBean // Mock Especializado do Spring
  BookService bookService;

  @Test
  @DisplayName("Deve criar um livro com sucesso")
  public void createBookTest() throws Exception{

    // representa o JSON a ser enviado, um dto
    BookDTO dto = createTestNewBook();

    // Representa o objeto Mockado que vai ser retornardo quando o 'service' executar 'save'
    // Perceba que, estamos mockadno um metodo de uma classe do 'main' do BookService
    Book savedBook = Book.builder().id(10l).author("Artur").title("As aventuras").isbn("001").build();


    // Mockando Serviço
    // Estou simulando o método Save do Controller de Book. Quando executado vai retornar SavedBook
    // Simula o retorno do banco de dados
    BDDMockito.given(bookService.save(Mockito.any(Book.class))).willReturn(savedBook);

    // ObjectMapper recebe um objeto e tranforma em JSON. Estou preparando uma reqsuição real
    String json = new ObjectMapper().writeValueAsString(dto);

    // Montando Requisição HTTP: post em 'BOOK_API' aceitando JSON
    MockHttpServletRequestBuilder request = MockMvcRequestBuilders
      .post(BOOK_API)
      .contentType(MediaType.APPLICATION_JSON)
      .accept(MediaType.APPLICATION_JSON)
      .content(json)
    ;

    // Importar métodos diretos assim fica mais legivel o 'status' e 'jsonPath'
    //    import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath/status;
    // Executo esse request e verifico o que voltou: status e conteudo do json de retorno
    mvc
      .perform(request)
      .andExpect( status().isCreated() )
      .andExpect( jsonPath("id").value(10l) )
      .andExpect( jsonPath("title").value(dto.getTitle()) )
      .andExpect( jsonPath("author").value(dto.getAuthor()) )
      .andExpect( jsonPath("isbn").value(dto.getIsbn()) )
    ;
  }

  @Test
  @DisplayName("Não Deve criar um livro quando houver erro de validação")
  public void createInvalidBookTest(){
    
  }

  private BookDTO createTestNewBook() {
    return BookDTO.builder().author("Artur").title("As aventuras").isbn("001").build();
}
  
}