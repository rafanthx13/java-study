package br.com.rafanthx13.FirstSpringProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstSpringProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
