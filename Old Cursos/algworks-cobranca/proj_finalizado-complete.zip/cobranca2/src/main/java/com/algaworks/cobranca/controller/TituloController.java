package com.algaworks.cobranca.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.Errors;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.algaworks.cobranca.model.StatusTitulo;
import com.algaworks.cobranca.model.Titulo;
import com.algaworks.cobranca.repository.filter.TituloFilter;
import com.algaworks.cobranca.servico.CadastroTituloService;

@Controller
@RequestMapping("/titulos")
public class TituloController {
	
	/* 	Como to repetindo muito o cadastroTitulo, vou colocalo como uma variavel so
	 * 		para evitar ter que repetir String e assim garantir menos erro.
	 * 	Além disso, sereve para manutenção
	 */
	private static final String CADASTRO_VIEW = "CadastroTitulo";
	
	@Autowired
	private CadastroTituloService cadastroTituloService;
	
	
	// 2.6 vamos colocar o objeto dos status para serem interado no thymeleaf
	// StatusTitulo.value() vai retornar todos os status possiveis, NAO O USAMOS pois tem o atributoDoModel
	@RequestMapping("/novo")
	public ModelAndView novo(){
		ModelAndView mv = new ModelAndView(CADASTRO_VIEW);
		/* 	Ao passar esse cara, o thymeleaf vai ligar pra parte de 	
		 * 		verificar se esse titulo tera ou nao mensagem
		 *	Eh necessario passar pois o titulo ficaria null e nao
		 * 		darai pra acessar nada daqulo que acessamos pra verificar erros
		 */
		mv.addObject(new Titulo());
		return mv;
	}
	
	/*	O objeto modelandview serve pra mandarmos a view(como faziamos com STRING) mas adicionando mais coisas do model
		Com esse validated, o spring vai VALIDAR de acordo com o que está no model 
		RedirectAttibutes server para redirecionar coisas pra outras requisiçoes URL
		Na aula 2.14, mandamos do tipo ModelAndView para String
	*/
	@RequestMapping(method = RequestMethod.POST)
	public String salvar(@Validated Titulo titulo, Errors errors, RedirectAttributes attributes){
	
		//Dessa forma, quando houver erro, nao vai nem tentar salvar no BD
		if(errors.hasErrors()){
			return CADASTRO_VIEW;
		}
		try{
			
			cadastroTituloService.salvar (titulo);
			// vamos mandar mensgem e seu conteudo mesmo redirecionando, 
			// pois, sem isso, sera como se nao tivessemos cadastrado um titulo
			attributes.addFlashAttribute("mensagem", "Título salvo com sucesso");
			return "redirect:/titulos/novo";
		} catch(IllegalArgumentException e){ 
			errors.rejectValue("dataVencimento", null, e.getMessage());
			return CADASTRO_VIEW;
		}
	}
	
	/* 	Esse ModelAtribute eh para toda model ter isso inserida
	 * vai retornar uma lista, seu nome rotulador para usala
	 * no thymeleaf sera:  statusTituloList
	 * 	Porem, vamos renomear para      
	 * 		todosStatusTitulo
	 */
	@ModelAttribute("todosStatusTitulo")
	public List<StatusTitulo> todosStatusTitulo(){
		return Arrays.asList(StatusTitulo.values());
	}
	
	/* 	3.10 fazendo search por descricao
	* 		ModelAttribute, serve pro Spring montar esse objeto aparitr do th:field do HTMl que tem filtro
	*		Asism, o spring vai criar o TituloFitler por ai
	*/
	@RequestMapping
	public ModelAndView pesquisar(@ModelAttribute("filtro") TituloFilter filtro){
		List<Titulo> todosTitulos = cadastroTituloService.filtrar(filtro);
		ModelAndView mv = new ModelAndView("PesquisaTitulo");
		mv.addObject("titulos",todosTitulos);
		return mv;
	}
	
	/*	Vamos deixar a url varialvel, assim, cada codigo posto na url sera lido para o @PathVariabel
	 * 	final do 2.15 => o hibernate pode a partir da codigo da url envaida, ja procurar no BD
	 *	e encontrar o titulo que tem essa URL e colocar dinamicamente no parametro de entrada
	 *	Ou seja, evita agente ter que da o comdando de procurar no banco com o findOne
	 *	Explicando edicao
	 * 		1. digitamos no simbolo do lapis, ele nos leva a URL do id do codigo e 
	 * 		2. colocamos um hidden pra codigo, para que, esse codigo fosse levado pra tela de cadastro
	 * 			pois nos nao digitamos o codigo, ele simplismente eh preenchido,
	 * 			--> sem ele, estariamos cadastrando outro ITEM, pois NAO HA CADASTRO DE CODIGO
	 * 			
	 * 		3. por @PathVariabel("codigo") Titulo titulo, o HIBERNATE vai colocar nesse titulo
	 * 				o objeto que tenha o codigo passado, isso evita darmos um finOne, ele da AUTO
	 * 		4. adicionamos entao esse objeto ao cadastro, no cadastro, por receber esse  objeto preenchido
	 * 				ele vai deixar preenchido nos fiels, semelhante aquele treco que os dados nao sairam emsmo com refresh
	 * 		5. Agente digita alguma modicaçao, como nao tem como inserir codigo, vai pro codigo que quermos
	 * 		6. A SACADA eh que, ao fazer o salvar(), ele vai ver que estamos fazendo um INSERT de algo que já existe, e aí, vai
	 * 				fazer um UPDATE
	 */
	
	@RequestMapping("{codigo}")
	public ModelAndView edicao(@PathVariable("codigo") Titulo titulo){
		// vai encontrar os dados do titulo no BD
		//Titulo titulo = titulos.findOne(codigo);
		ModelAndView mv = new ModelAndView(CADASTRO_VIEW);
		// Com isso, vou pra tela de cadastro e nos campos estarao os dados do titulo dessa url pra modificar
		mv.addObject(titulo);
		return mv;
	}
	
	//esse value = codigo eh semelhante ao da edicao, 
	// O path variabel serve pra URL virar a variavel de entrada do metodo
	@RequestMapping(value="{codigo}", method = RequestMethod.DELETE)
	public String excluir(@PathVariable Long codigo, RedirectAttributes attributes){
		cadastroTituloService.excluir(codigo);
		attributes.addFlashAttribute("mensagem", "Título excluído com sucesso!");
		return "redirect:/titulos";
	}
	
	/*3.7
	 pra eu nao procurar uma view, e simplismente retoranar apeanas uma string JS 
	 colocamos entao @ResponseBody ==> retorna uma string e nao uma view 
	 recebo uma requisiçao PUT e retorno uma string qualquer
	 */
	@RequestMapping(value = "/{codigo}/receber", method = RequestMethod.PUT)
	public @ResponseBody String receber(@PathVariable Long codigo){
		return cadastroTituloService.receber(codigo);
	}
}
