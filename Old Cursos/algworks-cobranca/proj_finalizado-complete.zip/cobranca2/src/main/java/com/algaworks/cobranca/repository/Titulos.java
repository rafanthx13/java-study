package com.algaworks.cobranca.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.algaworks.cobranca.model.Titulo;
/* Ja esta funcionadno, o Spring Data ja gera a implementaçao disso,
 * Isso ocorre por que ele ja tem uma implementaçao genérica
 */
public interface Titulos extends JpaRepository<Titulo, Long>{

	/*	Estamos criando uma consulta, será usada na pesquisa de título
	 * 		onde vamos procurar pela descrição
	 * 	Tem toda uma forma de fazer isos, que está na doc do JPA/HIBERNATE
	 */
	public List<Titulo> findByDescricaoContaining(String desrcicao);
}
