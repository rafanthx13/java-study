package com.algaworks.cobranca.repository.filter;

public class TituloFilter {
	
	private String descricao;

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
}
