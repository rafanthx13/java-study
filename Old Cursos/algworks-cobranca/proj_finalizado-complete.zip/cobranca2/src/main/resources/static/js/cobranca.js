// Arquivo de JS pra mexer no modal do DELETE
// Toda vez que o modal aparecer, um evento pode aparecer e eu posso usar JQUERY 

//quando esse evento ocorrer, eu quero executar essa funcao
// esse inciio tem igual no bootsrap
$('#confirmacaoExclusaoModal').on('show.bs.modal', function(event){
	//serve pra pegar o evento de apertar o buttao que disparou o evento
	var button = $(event.relatedTarget);
	
	//data do JQUERY recupera o dado do butao, aqules de th:attr
	var codigoTitulo = button.data('codigo');
	var descricaoTitulo = button.data('descricao');
	
	//peguei o modal no caso this, que tem haver com o HTMl de exclusao
	var modal = $(this);
	
	// peguei o modal e procuro pela tag de form
	var form = modal.find('form');
	
	//procuro o atributo action da tag da var from que foi previamente pegada
	//2.17 agora o accito pega de um valor fixo sempre e nao acumulara coiass na URL
	var action = form.data('url-base');
	
	//Esse eh um truque pra que , caso nao terminar com barra, colocar a barra
	// se nao terminar com barra, adiciona uma barra
	// 2.17 -Nessa parte da BUG se vc Cancela, pois acumula coisa na URL 
	if(!action.endsWith('/')){
		action += '/';
	}
	
	//assim vou conseguir concatenar url do form com o codigo pra deletar o determinado
	// vai ter a url com o codigo
	form.attr('action', action + codigoTitulo);
	
	//coloco uma mensagem dinamica/customizada no fromulario do HTML de exclusao
	modal.find('.modal-body span').html('Tem certeza que deseja excluir o titulo <strong>' + descricaoTitulo + '</strong>?');
});


$(function() {
	$('[rel="tooltip"]').tooltip();
});

// Config para mexer em maskMoney do JS, aula 3.3, foi definido uma class de js de marcação
$(function(){
	$('[rel=tooltip').tooltip();
	$('.js-currency').maskMoney({decimal: ',', thousands: '.', allowsZero: true});
	
	// 3.6
	// pro JS nao ser um comportamento default, pra nao fazer um GET pois nao queremos
	// Com isso, ao clicar a tela nao vai piscar
	// com o click do botao eu faço a req. Ajax
	$('.js-atualizar-status').on('click', function(event) {
		event.preventDefault();
		
		//vamos pegar do botao, um objeto Jquery
		var botaoReceber = $(event.currentTarget);
		var urlReceber = botaoReceber.attr('href');
		
		//3.7
		// o jquey vai fazer um put 
		var response = $.ajax({
			url: urlReceber,
			type: 'PUT'
		});
		
		// se o PUT der errado
		response.done(function(e) {
			var codigoTitulo = botaoReceber.data('codigo');
			$('[data-role=' + codigoTitulo + ']').html('<span class="label label-success">' + e +'</span>');
			
			// quando licar corretamente, vai fazer o botao sumir da tela
			botaoReceber.hide();
		});
		
		// se o PUT der errado
		response.fail(function(e){
			console.log(e);
			alert('Erro recebendo cobranca');
		});
		
	});
});
