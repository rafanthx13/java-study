insert into item (etiqueta, descricao, data_aquisicao) values ('NT0123', 'Notebook i7', sysdate());
insert into item (etiqueta, descricao, data_aquisicao) values ('AU9875', 'Ford Fiesta', sysdate());
